# Cloud Tic Tac Toe - Backend

## Usage

Install dependencies:
```bash
poetry install
```

Run the server:
```bash
poetry run hypercorn src/app:app
```